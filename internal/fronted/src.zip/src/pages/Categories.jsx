import "./Categories.css";
import React from "react";

function Categories() {
  // TODO: Add recipe object
  const [activeIndex, setActiveIndex] = React.useState(0);
  const categoryList = ["MEMORY", "TRANSEIVER MODULE", "POWER MODULE"];
  const choseCategory = (index) => {
    setActiveIndex(index);
  };

  return (
    <div className="categories">
      <ul>
        {categoryList.map((value, i) => (
          <li
            onClick={() => choseCategory(i)}
            className={activeIndex === i ? "active" : " "}
          >
            {value}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default Categories;
