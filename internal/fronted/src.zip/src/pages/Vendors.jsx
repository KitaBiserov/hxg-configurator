import React from "react";
import "../App.css";
import "./Categories.css";

function Vendors(name) {


  return (
    <div className="vendor-container">
        <div>{name}</div>
          
    </div>
  );
};

export default Vendors;
