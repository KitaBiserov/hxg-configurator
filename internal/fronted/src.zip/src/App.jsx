
import "./App.css";
import React from "react";
import items from "./assets/items.json";
import Categories from "./pages/Categories";
import EquipmentBlock from "./pages/EquipmentBlock";
import logo from "./assets/img/logo.png";
import CalculationBlock from "./pages/CalculationBlock";
import Vendors from "./pages/Vendors";
import vend from "./assets/vendors.json";

function App() {

  return (
    <div>
      
      <div className="grid-header">
        <div className="container-logo">
          <img width="200" src={logo} alt="logo"></img>
        </div>
        <div className="container-horizontal-header">
          <h4>VENDORS</h4>
        </div>
        <div className="container-empty"></div>
        <div className="container-horizontal-header">
          { vend.map((obj) => (<Vendors name={obj.name}/>  ))};
         
          
        </div>
      </div>

      <div className="grid-container">
        <div className="container-vertical">
         <Categories />
        </div>
        <div className="equipment-grid">
          
            
            
          
        </div>
      </div>
      <div className="grid-footer">
        {/* TODO: Add the prep work display */}
        <div></div>
        <CalculationBlock />
      </div>
    </div>
  );
}

export default App;
