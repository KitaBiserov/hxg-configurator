import React from "react";
import "../App.css";

function EquipmentBlock(key,title, price, description, type, imageURL) {

  return (
    <div className="equipment-block">
        <img className="equipment-icon" src={imageURL} alt="equipment"></img>
      <h3 className="equipment-title">Equipment: {title}</h3>
      <div>
        <h1>
          {description}
        </h1>
        <ul>
          {type.map((ty) => (
            <li key={key}>{ty}</li>
          ))}
        </ul>
        <div>{price}</div>
      </div>
    </div>
  );
}

export default EquipmentBlock;
